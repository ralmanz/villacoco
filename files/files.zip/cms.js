/**
 * Villa Coco CMS API
 * Cloudflare Pages Function
 *
 * GET  /api/cms        → returns current CMS content from KV (public)
 * POST /api/cms        → saves new CMS content to KV (requires admin password)
 * POST /api/cms/revert → reverts to previous saved version (requires admin password)
 *
 * KV Namespace binding: VILLA_COCO_CMS  (configure in Cloudflare Pages dashboard)
 * Environment variable:  ADMIN_PASSWORD  (configure in Cloudflare Pages dashboard)
 *
 * Keys used in KV:
 *   "cms_current"   → current live content (JSON string)
 *   "cms_backup"    → previous version for revert (JSON string)
 */

const CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Password',
};

export async function onRequest(context) {
  const { request, env } = context;
  const method = request.method.toUpperCase();
  const url = new URL(request.url);

  // Handle CORS preflight
  if (method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  // ── GET /api/cms — return current content (public, no auth needed) ──
  if (method === 'GET') {
    try {
      const raw = await env.VILLA_COCO_CMS.get('cms_current');
      if (!raw) {
        return json({}, 200);
      }
      return json(JSON.parse(raw), 200);
    } catch (e) {
      return json({ error: 'Failed to read content' }, 500);
    }
  }

  // ── POST — requires admin password ──
  if (method === 'POST') {
    // Auth check
    const password = request.headers.get('X-Admin-Password');
    const adminPassword = env.ADMIN_PASSWORD || 'villacoco2025';
    if (password !== adminPassword) {
      return json({ error: 'Unauthorized' }, 401);
    }

    const path = url.pathname;

    // POST /api/cms/revert — restore previous backup
    if (path.endsWith('/revert')) {
      try {
        const backup = await env.VILLA_COCO_CMS.get('cms_backup');
        if (!backup) {
          return json({ error: 'No backup available to revert to' }, 404);
        }
        // Current becomes new backup, backup becomes current
        const current = await env.VILLA_COCO_CMS.get('cms_current');
        if (current) {
          await env.VILLA_COCO_CMS.put('cms_backup', current);
        }
        await env.VILLA_COCO_CMS.put('cms_current', backup);
        return json({ success: true, message: 'Reverted to previous version' }, 200);
      } catch (e) {
        return json({ error: 'Revert failed' }, 500);
      }
    }

    // POST /api/cms — save new content
    try {
      const body = await request.json();
      if (!body || typeof body !== 'object') {
        return json({ error: 'Invalid content' }, 400);
      }

      // Backup current before overwriting
      const current = await env.VILLA_COCO_CMS.get('cms_current');
      if (current) {
        await env.VILLA_COCO_CMS.put('cms_backup', current);
      }

      // Save new content
      await env.VILLA_COCO_CMS.put('cms_current', JSON.stringify(body));
      return json({ success: true }, 200);
    } catch (e) {
      return json({ error: 'Save failed' }, 500);
    }
  }

  return json({ error: 'Method not allowed' }, 405);
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...CORS_HEADERS, 'Content-Type': 'application/json' },
  });
}
